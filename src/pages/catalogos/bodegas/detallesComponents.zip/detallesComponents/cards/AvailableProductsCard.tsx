import React from 'react';
import Card, { CardBody, CardHeader, CardTitle } from '@/components/ui/Card';
import AvailableProductsTable from '../tables/AvailableProductsTable';

interface Product {
	id: number;
	sku: string;
	name: string;
	brand?: {
		name: string;
	};
	stock?: number;
}

interface AvailableProductsCardProps {
	products: Product[];
	loading: boolean;
	onAttachProduct: (product: Product) => void;
}

const AvailableProductsCard: React.FC<AvailableProductsCardProps> = ({
	products,
	loading,
	onAttachProduct,
}) => {
	return (
		<Card>
			<CardHeader>
				<CardTitle>Productos Disponibles</CardTitle>
			</CardHeader>
			<CardBody>
				<AvailableProductsTable
					products={products}
					loading={loading}
					onAttachProduct={onAttachProduct}
				/>
			</CardBody>
		</Card>
	);
};

export default AvailableProductsCard;
