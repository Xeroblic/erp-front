import React from 'react';
import Card, { CardBody, CardHeader, CardTitle } from '@/components/ui/Card';
import AssociatedProductsTable from '../tables/AssociatedProductsTable';

interface Product {
	id: number;
	sku: string;
	name: string;
	brand_name?: string;
	quantity: number;
	sync_stock: boolean;
}

interface AssociatedProductsCardProps {
	products: Product[];
	allProducts: any[];
	updatingSyncIds: number[];
	onSyncToggle: (productId: number, turningOn: boolean, currentQty: number) => void;
	onRemoveProduct: (product: Product) => void;
}

const AssociatedProductsCard: React.FC<AssociatedProductsCardProps> = ({
	products,
	allProducts,
	updatingSyncIds,
	onSyncToggle,
	onRemoveProduct,
}) => {
	return (
		<Card>
			<CardHeader>
				<CardTitle>Productos Asociados ({products?.length || 0})</CardTitle>
			</CardHeader>
			<CardBody>
				<AssociatedProductsTable
					products={products}
					allProducts={allProducts}
					updatingSyncIds={updatingSyncIds}
					onSyncToggle={onSyncToggle}
					onRemoveProduct={onRemoveProduct}
				/>
			</CardBody>
		</Card>
	);
};

export default AssociatedProductsCard;
