import React from 'react';
import Button from '@/components/ui/Button';
import Icon from '@/components/icon/Icon';

interface Product {
	id: number;
	sku: string;
	name: string;
	brand?: {
		name: string;
	};
	stock?: number;
}

interface AvailableProductsTableProps {
	products: Product[];
	loading: boolean;
	onAttachProduct: (product: Product) => void;
}

const AvailableProductsTable: React.FC<AvailableProductsTableProps> = ({
	products,
	loading,
	onAttachProduct,
}) => {
	if (loading) {
		return (
			<div className='py-8 text-center'>
				<Icon icon='HeroArrowPath' className='animate-spin' />
			</div>
		);
	}

	if (products.length === 0) {
		return (
			<div className='py-8 text-center text-sm text-gray-600'>
				No hay productos disponibles
			</div>
		);
	}

	return (
		<div className='overflow-x-auto'>
			<table className='min-w-full divide-y divide-gray-200'>
				<thead className='bg-gray-50'>
					<tr>
						<th className='px-4 py-2 text-left text-xs font-medium text-gray-500'>
							SKU
						</th>
						<th className='px-4 py-2 text-left text-xs font-medium text-gray-500'>
							Nombre
						</th>
						<th className='px-4 py-2 text-left text-xs font-medium text-gray-500'>
							Marca
						</th>
						<th className='px-4 py-2 text-right text-xs font-medium text-gray-500'>
							Stock
						</th>
						<th className='px-4 py-2 text-center text-xs font-medium text-gray-500'>
							Acción
						</th>
					</tr>
				</thead>
				<tbody className='divide-y divide-gray-200 bg-white'>
					{products.map((p) => (
						<tr key={p.id} className='hover:bg-gray-50'>
							<td className='px-4 py-2 font-mono text-sm'>{p.sku}</td>
							<td className='px-4 py-2 text-sm'>{p.name}</td>
							<td className='px-4 py-2 text-sm text-gray-600'>
								{p.brand?.name ?? 'N/A'}
							</td>
							<td className='px-4 py-2 text-right text-sm'>{p.stock ?? 0}</td>
							<td className='px-4 py-2 text-center'>
								<div className='flex items-center justify-center gap-2'>
									<Button
										size='sm'
										variant='outline'
										color='blue'
										onClick={() => onAttachProduct(p)}>
										Asociar
									</Button>
								</div>
							</td>
						</tr>
					))}
				</tbody>
			</table>
		</div>
	);
};

export default AvailableProductsTable;
