import React from 'react';
import Button from '@/components/ui/Button';
import Icon from '@/components/icon/Icon';
import Badge from '@/components/ui/Badge';
import Checkbox from '@/components/form/Checkbox';
import { useNavigate } from 'react-router-dom';

interface Product {
	id: number;
	sku: string;
	name: string;
	brand_name?: string;
	quantity: number;
	sync_stock: boolean;
}

interface AssociatedProductsTableProps {
	products: Product[];
	allProducts: any[];
	updatingSyncIds: number[];
	onSyncToggle: (productId: number, turningOn: boolean, currentQty: number) => void;
	onRemoveProduct: (product: Product) => void;
}

const AssociatedProductsTable: React.FC<AssociatedProductsTableProps> = ({
	products,
	allProducts,
	updatingSyncIds,
	onSyncToggle,
	onRemoveProduct,
}) => {
	const navigate = useNavigate();

	if (!products || products.length === 0) {
		return (
			<div className='py-8 text-center text-sm text-gray-600'>No hay productos asociados</div>
		);
	}

	return (
		<div className='overflow-x-auto'>
			<table className='min-w-full divide-y divide-gray-200'>
				<thead className='bg-gray-50'>
					<tr>
						<th className='px-4 py-2 text-left text-xs font-medium text-gray-500'>
							SKU
						</th>
						<th className='px-4 py-2 text-left text-xs font-medium text-gray-500'>
							Nombre
						</th>
						<th className='px-4 py-2 text-left text-xs font-medium text-gray-500'>
							Marca
						</th>
						<th className='px-4 py-2 text-right text-xs font-medium text-gray-500'>
							Stock
						</th>
						<th className='px-4 py-2 text-right text-xs font-medium text-gray-500'>
							Cantidad
						</th>
						<th className='px-4 py-2 text-center text-xs font-medium text-gray-500'>
							Modo
						</th>
						<th className='px-4 py-2 text-center text-xs font-medium text-gray-500'>
							Acciones
						</th>
					</tr>
				</thead>
				<tbody className='divide-y divide-gray-200 bg-white'>
					{products.map((p) => (
						<tr key={p.id} className='hover:bg-gray-50'>
							<td className='px-4 py-2 font-mono text-sm'>{p.sku}</td>
							<td className='px-4 py-2 text-sm'>{p.name}</td>
							<td className='px-4 py-2 text-sm text-gray-600'>
								{p.brand_name ??
									allProducts.find((x) => x.id === p.id)?.brand?.name ??
									'N/A'}
							</td>
							<td className='px-4 py-2 text-right text-sm'>
								{allProducts.find((x) => x.id === p.id)?.stock ?? 0}
							</td>
							<td className='px-4 py-2 text-right font-semibold'>{p.quantity}</td>
							<td className='px-4 py-2 text-center'>
								{p.sync_stock ? (
									<Badge color='blue' variant='outline'>
										Auto-Sync
									</Badge>
								) : (
									<Badge color='gray' variant='outline'>
										Manual
									</Badge>
								)}
							</td>
							<td className='px-4 py-2 text-center'>
								<div className='flex items-center justify-center gap-2'>
									{updatingSyncIds.includes(p.id) && (
										<Icon icon='HeroArrowPath' className='animate-spin' />
									)}
									<Checkbox
										variant='switch'
										id={`sync-${p.id}`}
										checked={p.sync_stock}
										onChange={(e) => {
											const turningOn = e.target.checked;
											onSyncToggle(p.id, turningOn, p.quantity);
										}}
									/>

									<Button
										size='sm'
										variant='outline'
										onClick={() => navigate(`/producto/${p.id}`)}>
										Ver
									</Button>
									<Button
										size='sm'
										variant='outline'
										color='red'
										onClick={() => onRemoveProduct(p)}>
										Quitar
									</Button>
								</div>
							</td>
						</tr>
					))}
				</tbody>
			</table>
		</div>
	);
};

export default AssociatedProductsTable;
