# Comparación: useWarehouseManagement vs useWarehouseDetail

## 📊 Hooks Disponibles

### 1. `useWarehouseManagement` (General)

**Ubicación:** `src/pages/catalogos/bodegas/hooks/useWarehouseManagement.ts`

**Propósito:** Hook **general** para toda la gestión de bodegas (CRUD completo)

**Cuándo usar:**

- ✅ Página de listado de bodegas
- ✅ Dashboard de bodegas
- ✅ Cualquier página que necesite CRUD completo

**Funcionalidades:**

```typescript
{
  // State completo
  warehouses: IWarehouse[],
  warehouseDetail: IWarehouse | null,
  meta: PaginationMeta,
  stats: WarehouseStats,
  loading: boolean,
  warehouseDetailLoading: boolean,
  creating: boolean,
  updating: boolean,
  deleting: boolean,
  attachingProducts: boolean,
  detachingProduct: boolean,
  error: string | null,
  warehouseDetailError: string | null,

  // Operaciones CRUD
  loadWarehouses(),           // Listar
  loadWarehouseDetail(),      // Ver detalle
  handleCreateWarehouse(),    // Crear
  handleUpdateWarehouse(),    // Actualizar
  handleDeleteWarehouse(),    // Eliminar

  // Operaciones de productos
  handleAttachProducts(),     // Asociar
  handleDetachProduct(),      // Desasociar

  // Utils
  handleClearError(),
  handleClearDetail(),
}
```

---

### 2. `useWarehouseDetail` (Específico)

**Ubicación:** `src/pages/catalogos/bodegas/detallesComponents/hooks/useWarehouseDetail.ts`

**Propósito:** Hook **especializado** solo para la página de detalle

**Cuándo usar:**

- ✅ Página de detalle de bodega (`WarehouseDetailPage`)
- ✅ Cuando solo necesitas ver/editar productos asociados

**Funcionalidades:**

```typescript
{
  // State simplificado (solo lo necesario)
  warehouse: IWarehouse | null,
  loading: boolean,
  error: string | null,
  attachingProducts: boolean,
  detachingProduct: boolean,

  // Solo operaciones de detalle
  loadWarehouseDetail(),      // Ver detalle
  handleAttachProducts(),     // Asociar (con validaciones mejoradas)
  handleDetachProduct(),      // Desasociar (con validaciones mejoradas)
  handleClearDetail(),
  refreshDetail(),            // Refrescar después de cambios
}
```

**Ventajas:**

- 🚀 Más ligero (menos state)
- 🎯 Enfocado (solo lo necesario)
- ✅ Validaciones específicas
- 📝 Mensajes de error personalizados

---

### 3. `useWarehouseDetailModals` (UI State)

**Ubicación:** `src/pages/catalogos/bodegas/detallesComponents/hooks/useWarehouseDetailModals.ts`

**Propósito:** Gestionar el estado de la UI y modales

**Cuándo usar:**

- ✅ Siempre junto con `useWarehouseDetail`
- ✅ Para manejar apertura/cierre de modales

**Funcionalidades:**

```typescript
{
  // Estado UI
  productToRemove: Product | null,
  attachProduct: Product | null,
  attaching: boolean,
  qtyModal: {...},
  isEditable: boolean,
  updatingSyncIds: number[],

  // Control de modales
  openRemoveModal(),
  closeRemoveModal(),
  openAttachModal(),
  closeAttachModal(),
  openQtyModal(),
  closeQtyModal(),

  // Control UI
  toggleEditable(),
  addUpdatingId(),
  removeUpdatingId(),
  startAttaching(),
  finishAttaching(),
}
```

---

## 🔍 Comparación Detallada

### Escenario 1: Página de Listado de Bodegas

**❌ NO usar:** `useWarehouseDetail`
**✅ SÍ usar:** `useWarehouseManagement`

```tsx
// WarehousesListPage.tsx
const WarehousesListPage = () => {
	const {
		warehouses, // ✅ Necesario
		loading, // ✅ Necesario
		meta, // ✅ Necesario para paginación
		loadWarehouses, // ✅ Necesario
		handleDeleteWarehouse, // ✅ Necesario
	} = useWarehouseManagement(branchId);

	// Renderizar tabla de bodegas...
};
```

---

### Escenario 2: Página de Detalle de Bodega

#### Opción A: Usando hook general (⚠️ Ineficiente)

```tsx
// ❌ Trae TODO el state aunque no lo necesites
const {
	warehouseDetail,
	warehouses, // ❌ No necesario aquí
	meta, // ❌ No necesario aquí
	stats, // ❌ No necesario aquí
	creating, // ❌ No necesario aquí
	updating, // ❌ No necesario aquí
	deleting, // ❌ No necesario aquí
	loadWarehouseDetail,
	handleAttachProducts,
	handleDetachProduct,
} = useWarehouseManagement(branchId);
```

#### Opción B: Usando hooks específicos (✅ Recomendado)

```tsx
// ✅ Solo trae lo necesario
const {
	warehouse, // ✅ Solo el detalle
	loading, // ✅ Solo el loading del detalle
	attachingProducts, // ✅ Loading específico
	detachingProduct, // ✅ Loading específico
	loadWarehouseDetail,
	handleAttachProducts, // ✅ Con validaciones mejoradas
	handleDetachProduct, // ✅ Con validaciones mejoradas
	refreshDetail, // ✅ Utility adicional
} = useWarehouseDetail(branchId);

// ✅ Estado de UI separado
const modals = useWarehouseDetailModals();
```

---

## 📈 Beneficios de la Separación

### 1. Rendimiento

```typescript
// ❌ Hook general: Re-render cuando cambia CUALQUIER cosa
useWarehouseManagement(); // Escucha TODO el state.warehouse

// ✅ Hook específico: Re-render solo cuando cambia lo relevante
useWarehouseDetail(); // Escucha solo warehouseDetail, attachingProducts, etc.
```

### 2. Claridad

```typescript
// ❌ Confuso: ¿Qué hace este componente?
const { warehouses, warehouseDetail, creating, updating, ... } = useWarehouseManagement();

// ✅ Claro: Este componente maneja el detalle
const { warehouse, ... } = useWarehouseDetail();
const modals = useWarehouseDetailModals();
```

### 3. Validaciones Específicas

```typescript
// En useWarehouseDetail
handleAttachProducts: async (warehouseId, data) => {
	try {
		// ...
	} catch (e) {
		const msg = e?.response?.data?.message || e?.message;

		// ✅ Validaciones específicas del contexto de detalle
		if (msg?.includes('ya está asociado'))
			toast.warning('El producto ya se encuentra en la bodega');
		else if (msg?.includes('capacidad'))
			toast.error('No hay capacidad suficiente en la bodega');
		else if (msg?.includes('stock disponible'))
			toast.error('No hay stock disponible para sincronizar');
		// ...
	}
};
```

### 4. Separación de Responsabilidades

```typescript
// useWarehouseDetail: Lógica de negocio (API)
const api = useWarehouseDetail(branchId);

// useWarehouseDetailModals: Lógica de UI (modales, estado local)
const ui = useWarehouseDetailModals();

// Componente: Solo orquestación
const handleConfirmAttach = async (productId, sync, qty) => {
  ui.startAttaching();
  const success = await api.handleAttachProducts(...);
  if (success) {
    await api.refreshDetail(warehouseId);
    ui.closeAttachModal();
  }
  ui.finishAttaching();
};
```

---

## 🎯 Guía de Decisión

```
¿Necesitas CRUD completo de bodegas?
    ├─ SÍ → useWarehouseManagement
    └─ NO
        └─ ¿Solo trabajas con detalle y productos?
            ├─ SÍ → useWarehouseDetail + useWarehouseDetailModals
            └─ NO → Revisa tu caso de uso
```

---

## 💡 Ejemplo Práctico

### Antes (Un solo hook para todo)

```tsx
// ❌ 200 líneas de código mezclando todo
const WarehouseDetailPage = () => {
  const { warehouseDetail, loadWarehouseDetail, handleAttachProducts, ... } = useWarehouseManagement();
  const [productToRemove, setProductToRemove] = useState(null);
  const [attachProduct, setAttachProduct] = useState(null);
  const [attaching, setAttaching] = useState(false);
  const [qtyModal, setQtyModal] = useState({...});
  const [isEditable, setIsEditable] = useState(false);
  const [updatingSyncIds, setUpdatingSyncIds] = useState([]);

  const confirmAttach = async () => {
    setAttaching(true);
    try {
      const success = await handleAttachProducts(...);
      if (success) {
        await loadWarehouseDetail(...);
        setAttachProduct(null);
      }
    } finally {
      setAttaching(false);
    }
  };

  const handleSyncToggle = async (productId, turningOn, currentQty) => {
    if (!turningOn) {
      setQtyModal({ open: true, productId, initialQty: currentQty });
    } else {
      setUpdatingSyncIds((s) => [...s, productId]);
      try {
        await handleAttachProducts(...);
        await loadWarehouseDetail(...);
      } finally {
        setUpdatingSyncIds((s) => s.filter((id) => id !== productId));
      }
    }
  };

  // ... más código repetitivo
};
```

### Después (Hooks especializados)

```tsx
// ✅ 100 líneas de código limpio y legible
const WarehouseDetailPage = () => {
  const api = useWarehouseDetail(branchId);
  const ui = useWarehouseDetailModals();

  const handleConfirmAttach = async (productId, sync, qty) => {
    ui.startAttaching();
    const success = await api.handleAttachProducts(warehouse.id, {
      product_id: productId,
      quantity: sync ? null : qty,
      sync_stock: sync,
    });
    if (success) {
      await api.refreshDetail(warehouse.id);
      ui.closeAttachModal();
    }
    ui.finishAttaching();
  };

  const handleSyncToggle = async (productId, turningOn, currentQty) => {
    if (!turningOn) {
      ui.openQtyModal(productId, currentQty);
    } else {
      ui.addUpdatingId(productId);
      const success = await api.handleAttachProducts(...);
      if (success) await api.refreshDetail(warehouse.id);
      ui.removeUpdatingId(productId);
    }
  };

  // ... código mucho más limpio
};
```

---

## 📝 Resumen

| Hook                       | Ubicación                    | Propósito     | Cuándo Usar                    |
| -------------------------- | ---------------------------- | ------------- | ------------------------------ |
| `useWarehouseManagement`   | `/hooks/`                    | CRUD completo | Listado, Dashboard             |
| `useWarehouseDetail`       | `/detallesComponents/hooks/` | Solo detalle  | Página de detalle              |
| `useWarehouseDetailModals` | `/detallesComponents/hooks/` | Estado UI     | Junto con `useWarehouseDetail` |

**Regla de oro:** Usa el hook más específico para tu caso de uso. Si solo necesitas detalle, no uses el general. 🎯
